<?php
?>
<form action="change_code.php" method="post">
<table>
<h2>Change The Old Password</h2>
<tr>
   <th>Old Password</th>
   <td><input type="text" name="op"/></td>
</tr>
<tr>
   <th>New Password</th>
   <td><input type="text" name="np"/></td>
</tr>
<tr>
   <th>Change New Password</th>
   <td><input type="text" name="cnp"/></td>
</tr>
<tr>
   <td><input type="submit" value="change password"/><td>
</tr>
</table>
</form>