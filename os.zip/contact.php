<?php
?>
<form action="contact_code.php" method="post">
<table>
	<h1>Contact Us</h1>
		<tr>
	<th><label for="exampleFormControlInput1" class="form-label">Name</label></th>
  <td><input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Your Name" name="name"></td>
	</tr>
	
	<tr>
	<th><label for="exampleFormControlInput1" class="form-label">Email</label></th>
  <td><input type="eamil" class="form-control" id="exampleFormControlInput1" placeholder="Enter Your Email" name="email"></td>
	</tr>
<tr>
	<th><label for="exampleFormControlInput1" class="form-label">Mobile</label></th>
  <td><input type="number" class="form-control" id="exampleFormControlInput1" placeholder="Enter Your Mobile Number " name="mobile"></td>
	</tr>
	<tr>
		<tr>
  <th><label for="exampleFormControlTextarea1" class="form-label">Message</label></th>
  <td><textarea class="form-control" id="exampleFormControlTextarea1" rows="3"  placeholder="Message" name="message"></textarea></td>
</tr> 
<tr>
<td><input type="submit"</td>
</tr>
</table>
</form>